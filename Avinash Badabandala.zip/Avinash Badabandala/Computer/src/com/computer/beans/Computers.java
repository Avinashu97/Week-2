package com.computer.beans;

public interface Computers {
	
	public String getBrand();
	
	public String getPrice();
	
	public String getProcessor();
	
	

}
