package com.comp.AbstractFactory;

import com.computer.beans.Computers;

public interface ComputerAbstractFactory {
       
	public Computers createComputer();
}
